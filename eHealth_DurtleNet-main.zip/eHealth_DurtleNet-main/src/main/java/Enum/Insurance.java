package Enum;

/**
 * Never used
 * @author Viktor Benini, StudentID: 12989876
 */
public enum Insurance{
    PUBLIC, PRIVATE
}