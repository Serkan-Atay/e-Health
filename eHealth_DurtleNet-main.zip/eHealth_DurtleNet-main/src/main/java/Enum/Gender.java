package Enum;

/**
 * Gender ones was intended to implement but never used
 * @author Viktor Benini, StudentID: 1298976
 */
public enum Gender{
    MALE, FEMALE, VARIOUS
}