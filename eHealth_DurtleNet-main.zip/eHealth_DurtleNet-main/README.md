# eHealth_DurtleNet
FUAS Java project to create a eHealth system to schedule doctor appointments

The JavaDocumentation can be find in the project under the folder called the same way
